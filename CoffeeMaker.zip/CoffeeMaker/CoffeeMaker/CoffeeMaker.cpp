// CoffeeMaker.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>

class Hopper
{
public:
	double beans = 0;
	double beanGrounds = 0;

	void AddBeans(int beanos)
	{
		beans = beans + beanos;
	}

	void GrindBeans()
	{
		beans = 0;
		beanGrounds = beans / 4.5;
	}

	bool HopperCoffee()
	{
		if (beanGrounds >= 10)
		{
			beanGrounds = beanGrounds - 10;
			return true;
		}
		else
		{
			return false;
		}
	}
};

class Reservoir
{
public:
	int water = 0;

	void AddWater(int watah)
	{
		water = water + watah;
	}

	bool ReservoirCoffee()
	{
		if (water >= 1)
		{
			water = water - 1;
			return true;
		}
		else
		{
			return false;
		}
	}
};

class Heater
{
public:
	int temp = 75;

	void Heat()
	{
		if (temp < 185)
		{
			temp = temp + 10;
		}
	}

	bool HeaterCoffee()
	{
		if (temp >= 185)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
};

int main()
{
    std::cout << "Please input how many cups of coffee you want?";
	int cups;
	std::cin >> cups;

	std::cout << "Please input the number of coffee beans you are placing in the hopper";
	int beans; 
	std::cin >> beans;

	std::cout << "Please input the number of cups of water you are pouring in the reservoir";
	int wcups;
	std::cin >> wcups;

	Hopper myHopper;
	myHopper.AddBeans(beans);
	myHopper.GrindBeans();

	Reservoir myReservoir;
	myReservoir.AddWater(wcups);

	Heater myHeater;


	int cupsc = 0 ;
	
	while (myHeater.temp < 100)
	{
		myHeater.Heat();
	}
	
	for (int i = 0; i < cups; i++)
	{	
		if (myHopper.HopperCoffee() && myReservoir.ReservoirCoffee() && myHeater.HeaterCoffee())
		{
			cupsc = cupsc+1;
		}
	}

	std::cout << "You have made " << cupsc << " cups of coffee.";

}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
