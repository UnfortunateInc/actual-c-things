// Calculator.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <stack>
#include <string>

int Calculate(double x, char oper, double y)
{
	switch (oper)
	{
	case '+':
		return x + y;
	case '-':
		return x - y;
	case '*':
		return x * y;
	case '/':
		return x / y;
	default:
		return 0;
	}
}

int Undo(char redo)
{
	switch (redo)
	{
	case 'r':
		return 1;
	default:
		return 0;
	}
}

int main()
{
	double x = 0.0;
	double y = 0.0;
	double result = 0.0;
	char oper = '+';
	char redo = 'n';
	std::stack<int> redostack;

	std::cout << "Calculator Console Application\n";
	std::cout << "Please enter operations to perform. Format: (num1)(operator)(num2)\n";

	std::cin >> x >> oper >> y;
	result = Calculate(x, oper, y);
	std::cout << "Result is: " << result;
	redostack.push(result);
	while (true)
	{
		std::cout << "Would you like to undo the previous function?\n Answer y or n\n";
		std::cin >> redo;

		switch (redo)
		{
		case 'n':
			{
				std::cout << "input a function";
				std::cin >> x >> oper >> y;
				result = Calculate(x, oper, y);
				std::cout << "Result is: " << result;
				redostack.push(result);
			}		
		case 'y':
			{
				if (!redostack.empty())
				std::cout << redostack.top();
				redostack.pop();
			}
		}
	}

	return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
