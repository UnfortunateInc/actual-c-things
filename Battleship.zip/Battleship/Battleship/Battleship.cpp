// Battleship.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <string>
#include <vector>
#include <algorithm>

void PlayerPlace()
{

}

int main()
{
    std::cout << "Please Declare the size of the battlefield you wish to play on \n";
	std::cout << "Submit your answer as a single integer from 5 to 10 and I will plot out an x by x area of ocean with which we will battle: \n";
	int fieldSize;
	std::cin >> fieldSize;

	std::cout << "You have selected a grid of " << fieldSize << " by " << fieldSize << "\n";

	std::cout << "Lovely, now you may place your ships. You have 5 of them. \n";
	std::cout << "Please select your ship positions by inputting two integers in sequence to form an (x,y) coordinate on the field.\n";
	std::cout << "I wont watch dont worry.\nPromise. \n ";

	int playerShip1a;
	int playerShip1b;
	int playerShip2a;
	int playerShip2b;
	int playerShip3a;
	int playerShip3b;
	int playerShip4a;
	int playerShip4b;
	int playerShip5a;
	int playerShip5b;

	std::string shipCreate;


	for (int i = 1; i <= 5; i++)
	{
		if (i == 1)
		{
			shipCreate = "first";			
		}
		else if (i == 2)
		{
			shipCreate = "second";
		}
		else if (i == 3)
		{
			shipCreate = "third";
		}
		else if (i == 4)
		{
			shipCreate = "fourth";
		}
		else if (i == 5)
		{
			shipCreate = "fifth";
		}

		std::cout << "\nSelect the first coordinate of your " << shipCreate << " ship: \n";

		if (i == 1)
		{
			std::cin >> playerShip1a;
		}
		if (i == 2)
		{
			std::cin >> playerShip2a;
		}
		if (i == 3)
		{
			std::cin >> playerShip3a;
		}
		if (i == 4)
		{
			std::cin >> playerShip4a;
		}
		if (i == 5)
		{
			std::cin >> playerShip5a;
		}

		std::cout << "Now elect the second coordinate of your " << shipCreate << " ship: \n";

		if (i == 1)
		{
			std::cin >> playerShip1b;
		}
		if (i == 2)
		{
			std::cin >> playerShip2b;
		}
		if (i == 3)
		{
			std::cin >> playerShip3b;
		}
		if (i == 4)
		{
			std::cin >> playerShip4b;
		}
		if (i == 5)
		{
			std::cin >> playerShip5b;
		}

		std::cout << "Your " << shipCreate << " ship has been placed at: \n";

		if (i == 1)
		{
			std::cout << "(" << playerShip1a << "," << playerShip1b << ")";
		}
		if (i == 2)
		{
			std::cout << "(" << playerShip2a << "," << playerShip2b << ")";
		}
		if (i == 3)
		{
			std::cout << "(" << playerShip3a << "," << playerShip3b << ")";
		}
		if (i == 4)
		{
			std::cout << "(" << playerShip4a << "," << playerShip4b << ")";
		}
		if (i == 5)
		{
			std::cout << "(" << playerShip5a << "," << playerShip5b << ")";
		}	
	}

	int aiShip1a;
	int aiShip1b;
	int aiShip2a;
	int aiShip2b;
	int aiShip3a;
	int aiShip3b;
	int aiShip4a;
	int aiShip4b;
	int aiShip5a;
	int aiShip5b;

	// each column has a list of values from 1 to fieldSize, and when a random int is chosen to determine column, take a random int
	// from the list and set it to the row, then remove that element from the list.

	// set up column vector
	std::vector<int> ColVect;
	std::vector<int> ShipColVect;
	int temp;
	for (int q = 1; q <= fieldSize; q++)
	{
		ColVect.push_back(q);
	}
	for (int q = 1; q <= 5; q++)
	{
		std::random_shuffle(ColVect.begin(), ColVect.end());
		temp = ColVect.at(0);
		ShipColVect.push_back(temp);
	}
	aiShip1a = ShipColVect.at(0);
	ShipColVect.erase (ShipColVect.begin() + 0);
	aiShip2a = ShipColVect.at(0);
	ShipColVect.erase (ShipColVect.begin() + 0);
	aiShip3a = ShipColVect.at(0);
	ShipColVect.erase (ShipColVect.begin() + 0);
	aiShip4a = ShipColVect.at(0);
	ShipColVect.erase (ShipColVect.begin() + 0);
	aiShip5a = ShipColVect.at(0);
	ShipColVect.erase (ShipColVect.begin() + 0);

	//set up all potential row vectors
	std::vector<int> RowVect1;
	for (int q = 1; q <= fieldSize; q++)
	{
		RowVect1.push_back(q);
	}
	std::vector<int> RowVect2;
	for (int q = 1; q <= fieldSize; q++)
	{
		RowVect2.push_back(q);
	}
	std::vector<int> RowVect3;
	for (int q = 1; q <= fieldSize; q++)
	{
		RowVect3.push_back(q);
	}
	std::vector<int> RowVect4;
	for (int q = 1; q <= fieldSize; q++)
	{
		RowVect4.push_back(q);
	}
	std::vector<int> RowVect5;
	for (int q = 1; q <= fieldSize; q++)
	{
		RowVect5.push_back(q);
	}
	std::vector<int> RowVect6;
	for (int q = 1; q <= fieldSize; q++)
	{
		RowVect6.push_back(q);
	}
	std::vector<int> RowVect7;
	for (int q = 1; q <= fieldSize; q++)
	{
		RowVect7.push_back(q);
	}
	std::vector<int> RowVect8;
	for (int q = 1; q <= fieldSize; q++)
	{
		RowVect8.push_back(q);
	}
	std::vector<int> RowVect9;
	for (int q = 1; q <= fieldSize; q++)
	{
		RowVect9.push_back(q);
	}
	std::vector<int> RowVect10;
	for (int q = 1; q <= fieldSize; q++)
	{
		RowVect10.push_back(q);
	}
	
	//shuffle em
	std::random_shuffle(RowVect1.begin(), RowVect1.end());
	std::random_shuffle(RowVect2.begin(), RowVect2.end());
	std::random_shuffle(RowVect3.begin(), RowVect3.end());
	std::random_shuffle(RowVect4.begin(), RowVect4.end());
	std::random_shuffle(RowVect5.begin(), RowVect5.end());
	std::random_shuffle(RowVect6.begin(), RowVect6.end());
	std::random_shuffle(RowVect7.begin(), RowVect7.end());
	std::random_shuffle(RowVect8.begin(), RowVect8.end());
	std::random_shuffle(RowVect9.begin(), RowVect9.end());
	std::random_shuffle(RowVect10.begin(), RowVect10.end());

	int tempassign;
	for (int i = 1; i <= 5; i++)
	{
		tempassign = rand() % fieldSize + 1;

		if (tempassign == 1)
		{
			tempassign = RowVect1.at(0);
			RowVect1.erase(RowVect1.begin() + 0);
		}
		else if (tempassign == 2)
		{
			tempassign = RowVect2.at(0);
			RowVect2.erase(RowVect2.begin() + 0);
		}
		else if (tempassign == 3)
		{
			tempassign = RowVect3.at(0);
			RowVect3.erase(RowVect3.begin() + 0);
		}
		else if (tempassign == 4)
		{
			tempassign = RowVect4.at(0);
			RowVect4.erase(RowVect4.begin() + 0);
		}
		else if (tempassign == 5)
		{
			tempassign = RowVect5.at(0);
			RowVect5.erase(RowVect5.begin() + 0);
		}
		else if (tempassign == 6)
		{
			tempassign = RowVect6.at(0);
			RowVect6.erase(RowVect6.begin() + 0);
		}
		else if (tempassign == 7)
		{
			tempassign = RowVect7.at(0);
			RowVect7.erase(RowVect7.begin() + 0);
		}
		else if (tempassign == 8)
		{
			tempassign = RowVect8.at(0);
			RowVect8.erase(RowVect8.begin() + 0);
		}
		else if (tempassign == 9)
		{
			tempassign = RowVect9.at(0);
			RowVect9.erase(RowVect9.begin() + 0);
		}
		else if (tempassign == 10)
		{
			tempassign = RowVect2.at(0);
			RowVect10.erase(RowVect10.begin() + 0);
		}

		//assign ship coordinates to tempassign
		if (i == 1)
		{
			aiShip1b = tempassign;
		}
		if (i == 2)
		{
			aiShip2b = tempassign;
		}
		if (i == 3)
		{
			aiShip3b = tempassign;
		}
		if (i == 4)
		{
			aiShip4b = tempassign;
		}
		if (i == 5)
		{
			aiShip5b = tempassign;
		}
	}
	

	//PlayerFire
	std::cout << "\nYou have now placed all of your ships, I have placed mine as well. Let us begin.";

	std::cout << "\nMake the first move. Select coordinate points as you did before to fire.";
	int playerFire1;
	int playerFire2;
	bool gameOver = false;
	bool hit;
	int playerLife = 5;
	int aiLife = 5;
	
	int aiFire1;
	int aiFire2;

	//aiFire2 set up vectors
	std::vector<int> RowFire1;
	for (int q = 1; q <= fieldSize; q++)
	{
		RowFire1.push_back(q);
	}
	std::vector<int> RowFire2;
	for (int q = 1; q <= fieldSize; q++)
	{
		RowFire2.push_back(q);
	}
	std::vector<int> RowFire3;
	for (int q = 1; q <= fieldSize; q++)
	{
		RowFire3.push_back(q);
	}
	std::vector<int> RowFire4;
	for (int q = 1; q <= fieldSize; q++)
	{
		RowFire4.push_back(q);
	}
	std::vector<int> RowFire5;
	for (int q = 1; q <= fieldSize; q++)
	{
		RowFire5.push_back(q);
	}
	std::vector<int> RowFire6;
	for (int q = 1; q <= fieldSize; q++)
	{
		RowFire6.push_back(q);
	}
	std::vector<int> RowFire7;
	for (int q = 1; q <= fieldSize; q++)
	{
		RowFire7.push_back(q);
	}
	std::vector<int> RowFire8;
	for (int q = 1; q <= fieldSize; q++)
	{
		RowFire8.push_back(q);
	}
	std::vector<int> RowFire9;
	for (int q = 1; q <= fieldSize; q++)
	{
		RowFire9.push_back(q);
	}
	std::vector<int> RowFire10;
	for (int q = 1; q <= fieldSize; q++)
	{
		RowFire10.push_back(q);
	}

	//shuffle em
	std::random_shuffle(RowFire1.begin(), RowFire1.end());
	std::random_shuffle(RowFire2.begin(), RowFire2.end());
	std::random_shuffle(RowFire3.begin(), RowFire3.end());
	std::random_shuffle(RowFire4.begin(), RowFire4.end());
	std::random_shuffle(RowFire5.begin(), RowFire5.end());
	std::random_shuffle(RowFire6.begin(), RowFire6.end());
	std::random_shuffle(RowFire7.begin(), RowFire7.end());
	std::random_shuffle(RowFire8.begin(), RowFire8.end());
	std::random_shuffle(RowFire9.begin(), RowFire9.end());
	std::random_shuffle(RowFire10.begin(), RowFire10.end());


	while (gameOver == false)
	{
		std::cout << "\nSelect your first coordinate (column)\n";
		std::cin >> playerFire1;
		std::cout << "Select your second coordinate (row)\n";
		std::cin >> playerFire2;
		std::cout << "You have fired at coordinate (" << playerFire1 << "," << playerFire2 << ")\n";
		hit = false;
		
		//player fire/hit detection
		if (playerFire1 == aiShip1a)
		{
			if (playerFire2 == aiShip1b)
			{
				hit = true;
				std::cout << "You have struck my ship!\n";
				//send the ship to the bottom of the ocean (remove from grid)
				aiShip1a = -1;
				aiShip1b = -1;
			}
		}
		else if (playerFire1 == aiShip2a)
		{
			if (playerFire2 == aiShip2b)
			{
				hit = true;
				std::cout << "You have struck my ship!\n";
				//send the ship to the bottom of the ocean (remove from grid)
				aiShip2a = -1;
				aiShip2b = -1;
			}
		}
		else if (playerFire1 == aiShip3a)
		{
			if (playerFire2 == aiShip3b)
			{
				hit = true;
				std::cout << "You have struck my ship!\n";
				//send the ship to the bottom of the ocean (remove from grid)
				aiShip3a = -1;
				aiShip3b = -1;
			}
		}
		else if (playerFire1 == aiShip4a)
		{
			if (playerFire2 == aiShip4b)
			{
				hit = true;
				std::cout << "You have struck my ship!\n";
				//send the ship to the bottom of the ocean (remove from grid)
				aiShip4a = -1;
				aiShip4b = -1;
			}
		}
		else if (playerFire1 == aiShip5a)
		{
			if (playerFire2 == aiShip5b)
			{
				hit = true;
				std::cout << "You have struck my ship!\n";
				//send the ship to the bottom of the ocean (remove from grid)
				aiShip5a = -1;
				aiShip5b = -1;
			}
		}

		if (hit == false)
		{
			std::cout << "Miss!\n";
		}
		else if (hit)
		{
			aiLife--;
			if (aiLife == 0)
			{
				gameOver = true;
			}
		}
		std::cout << "Now I will make MY shot:\n";
		
		//aiFire1 assign
		aiFire1 = rand() % fieldSize + 1;
		

		//aiFire2 assign
		int tempassign;
				
			tempassign = rand() % fieldSize + 1;

			if (tempassign == 1 && !RowFire1.empty())
			{
				tempassign = RowFire1.at(0);
				RowFire1.erase(RowFire1.begin() + 0);
			}
			else if (tempassign == 2 && !RowFire2.empty())
			{
				tempassign = RowFire2.at(0);
				RowFire2.erase(RowFire2.begin() + 0);
			}
			else if (tempassign == 3 && !RowFire3.empty())
			{
				tempassign = RowFire3.at(0);
				RowFire3.erase(RowFire3.begin() + 0);
			}
			else if (tempassign == 4 && !RowFire4.empty())
			{
				tempassign = RowFire4.at(0);
				RowFire4.erase(RowFire4.begin() + 0);
			}
			else if (tempassign == 5 && !RowFire5.empty())
			{
				tempassign = RowFire5.at(0);
				RowFire5.erase(RowFire5.begin() + 0);
			}
			else if (tempassign == 6 && !RowFire6.empty())
			{
				tempassign = RowFire6.at(0);
				RowFire6.erase(RowFire6.begin() + 0);
			}
			else if (tempassign == 7 && !RowFire7.empty())
			{
				tempassign = RowFire7.at(0);
				RowFire7.erase(RowFire7.begin() + 0);
			}
			else if (tempassign == 8 && !RowFire8.empty())
			{
				tempassign = RowFire8.at(0);
				RowFire8.erase(RowFire8.begin() + 0);
			}
			else if (tempassign == 9 && !RowFire9.empty())
			{
				tempassign = RowFire9.at(0);
				RowFire9.erase(RowFire9.begin() + 0);
			}
			else if (tempassign == 10 && !RowFire10.empty())
			{
				tempassign = RowFire10.at(0);
				RowFire10.erase(RowFire10.begin() + 0);
			}
			aiFire2 = tempassign;

			//ai fire/hit detection
			hit = false;
			if (aiFire1 == playerShip1a)
			{
				if (aiFire2 == playerShip1b)
				{
					hit = true;
					std::cout << "I have struck your ship at (" << playerShip1a << "," << playerShip1b << ")!\n";
					//send the ship to the bottom of the ocean (remove from grid)
					playerShip1a = -1;
					playerShip1b = -1;
				}
			}
			else if (aiFire1 == playerShip2a)
			{
				if (aiFire2 == playerShip2b)
				{
					hit = true;
					std::cout << "I have struck your ship at (" << playerShip2a << "," << playerShip2b << ")!\n";
					//send the ship to the bottom of the ocean (remove from grid)
					playerShip2a = -1;
					playerShip2b = -1;
				}
			}
			else if (aiFire1 == playerShip3a)
			{
				if (aiFire2 == playerShip3b)
				{
					hit = true;
					std::cout << "I have struck your ship at (" << playerShip3a << "," << playerShip3b << ")!\n";
					//send the ship to the bottom of the ocean (remove from grid)
					playerShip3a = -1;
					playerShip3b = -1;
				}
			}
			else if (aiFire1 == playerShip4a)
			{
				if (aiFire2 == playerShip4b)
				{
					hit = true;
					std::cout << "I have struck your ship at (" << playerShip4a << "," << playerShip4b << ")!\n";
					//send the ship to the bottom of the ocean (remove from grid)
					playerShip4a = -1;
					playerShip4b = -1;
				}
			}
			else if (aiFire1 == playerShip5a)
			{
				if (aiFire2 == playerShip5b)
				{
					hit = true;
					std::cout << "I have struck your ship at (" << playerShip5a << "," << playerShip5b << ")!\n";
					//send the ship to the bottom of the ocean (remove from grid)
					playerShip5a = -1;
					playerShip5b = -1;
				}
			}

			if (!hit)
			{
				std::cout << "I missed...\n";
			}
			if (hit)
			{
				playerLife--;
					if (playerLife == 0)
					{
						gameOver = true;
					}
			}

	}

	if (playerLife == 0)
	{
		std::cout << "You Lose!";
	}
	else if (aiLife == 0)
	{
		std::cout << "You Win!";
	}

}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
